import os
import struct

MAP_NOT_DETECTED = 255

FILENAME_SIZE = 256
ENTRY_SIZE = 96
NAME_SIZE = 80
SIZE_POS = 80
MAPPER_POS = 84
GEN_POS = 86

mapper_table = [
    "generic8",
    "generic16",
    "konami5",
    "konami4",
    "ascii8",
    "ascii16",
    "gamemaster2",
    "fmpac",
    "ascii16ex",
    "rtype",
    "nextor_ram",
    "disk",
    "plain0000",
    "plain4000",
    "plain8000",
    "neo16",
    "neo8",
    "konamiultimate",
    None
]

msxgen_table = [
    "msx1",
    "msx2",
    "msx2+",
    "turbor",
    None
]

def search_table(text, table):
    for i, item in enumerate(table):
        if item is None:
            break
        p = text.find("_")
        if p != -1:
            p = text.find(item, p)
            if p != -1 and (p + len(item) == len(text) or text[p + len(item)] in ['_', '.']):
                return i
    return 255

def main():
    filecount = 0
    skipcount = 0

    try:
        with open("rom.cat", "wb") as f_output:
            f_output.write(b"MSXPICO_ROM_CAT\x00")

            for filename in os.listdir('.'):
                name = filename[:FILENAME_SIZE]
                name_lc = name.lower()

                if name_lc.endswith(".rom"):
                    filesize = 0

                    mapper = search_table(name_lc, mapper_table)
                    msxgen = search_table(name_lc, msxgen_table)

                    with open(filename, "rb") as f_input:
                        f_input.seek(0, os.SEEK_END)
                        filesize = f_input.tell()
                        f_input.seek(0)
                        filesize = (filesize + 15) & 0xfffffff0
                        buffer = f_input.read(filesize)

                    p = name.find("_")
                    if p != -1:
                        name = name[:p]

                    if mapper < MAP_NOT_DETECTED and msxgen <= 3:
                        print(f"Name: {name} | Mapper: {mapper_table[mapper]} | Generation: {msxgen_table[msxgen]}")

                        entry = bytearray(ENTRY_SIZE)
                        entry[: len(name)] = name.encode("ascii")
                        struct.pack_into("<I", entry, SIZE_POS, filesize)
                        entry[MAPPER_POS] = mapper
                        entry[GEN_POS] = msxgen

                        f_output.write(entry)
                        f_output.write(buffer)

                        filecount += 1
                    else:
                        print(f"Name: {name} Mapper or generation not specified, skipped!")
                        skipcount += 1

            entry = bytearray(ENTRY_SIZE)
            f_output.write(entry)

            print(f"Files added : {filecount}")
            print(f"Files skipped : {skipcount}")
            print(f"rom.cat file size : {f_output.tell()}")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()

